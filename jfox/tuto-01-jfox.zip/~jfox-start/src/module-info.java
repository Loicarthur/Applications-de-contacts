module jfox.start {

	exports jfox.start;

	requires transitive jfox;
}