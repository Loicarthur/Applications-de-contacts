open module labyrinthe {
	exports labyrinthe;

	requires javafx.controls;
	requires javafx.graphics;
	requires transitive jfox;
	requires javafx.base; 
}